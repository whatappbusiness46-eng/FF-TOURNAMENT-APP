const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json({limit:'1mb'}));

const PORT = process.env.PORT || 10000;
const ADMIN_TOKEN = process.env.ADMIN_TOKEN;
const JWT_SECRET = process.env.JWT_SECRET;
if (!ADMIN_TOKEN || !JWT_SECRET) {
  console.warn('ADMIN_TOKEN and JWT_SECRET must be set in production.');
}

const DATA_DIR = path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'db.json');
fs.mkdirSync(DATA_DIR, {recursive:true});

const defaults = {
  settings: {
    appName:'ZyroX Arena', currency:'BDT', referralPercent:5,
    supportTelegram:'', bkashNumber:'', nagadNumber:'',
    bannerText:'PLAY • COMPETE • WIN'
  },
  modes: [
    {id:'br', name:'BR MATCH', game:'Free Fire', enabled:true, count:0},
    {id:'cs', name:'CS 4 VS 4', game:'Free Fire', enabled:true, count:0},
    {id:'lw', name:'LONE WOLF', game:'Free Fire', enabled:true, count:0},
    {id:'clash', name:'CLASH SQUAD', game:'Free Fire', enabled:true, count:0}
  ],
  rules: {
    br:{entryFee:5, perKill:2.5, rewards:[{rank:'1',amount:50},{rank:'2',amount:30},{rank:'3',amount:20},{rank:'4-5',amount:10}]},
    cs:{entryFee:25, winnerReward:40, secondReward:0},
    lw:{entryFee:30, winnerReward:30}
  },
  matches:[], users:[], withdrawals:[], deposits:[], statements:[], notifications:[]
};

function load(){
  if(!fs.existsSync(DATA_FILE)){ save(defaults); return JSON.parse(JSON.stringify(defaults)); }
  try{return JSON.parse(fs.readFileSync(DATA_FILE,'utf8'));}catch(e){save(defaults);return JSON.parse(JSON.stringify(defaults));}
}
function save(db){fs.writeFileSync(DATA_FILE, JSON.stringify(db,null,2));}
let db=load();
function id(prefix){return prefix+'_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7);}
function admin(req,res,next){
  const token=req.headers['x-admin-token'];
  if(!ADMIN_TOKEN || token!==ADMIN_TOKEN) return res.status(401).json({error:'Invalid admin token'});
  next();
}
function auth(req,res,next){
  const h=req.headers.authorization||''; const token=h.startsWith('Bearer ')?h.slice(7):'';
  try{req.user=jwt.verify(token,JWT_SECRET);next();}catch(e){res.status(401).json({error:'Login required'});}
}
function userById(uid){return db.users.find(u=>u.id===uid);}

app.get('/api/health',(req,res)=>res.json({ok:true,app:'ZyroX Arena',time:new Date().toISOString()}));
app.get('/api/public/config',(req,res)=>res.json({settings:db.settings,modes:db.modes,rules:db.rules}));
app.get('/api/matches',(req,res)=>res.json(db.matches.filter(m=>m.status==='open')));
app.get('/api/leaderboard',(req,res)=>{
  const rows=db.users.map(u=>({name:u.name,winnings:u.winnings||0,matches:u.matches||0})).sort((a,b)=>b.winnings-a.winnings).slice(0,20);
  res.json(rows);
});

app.post('/api/auth/demo',(req,res)=>{
  const name=String(req.body.name||'Player').trim().slice(0,30);
  let u=db.users.find(x=>x.name.toLowerCase()===name.toLowerCase());
  if(!u){u={id:id('u'),name,balance:0,winnings:0,matches:0,referrals:0,referralCode:'ZX'+Math.random().toString(36).slice(2,8).toUpperCase()};db.users.push(u);save(db);}
  const token=jwt.sign({uid:u.id},JWT_SECRET,{expiresIn:'30d'});
  res.json({token,user:u});
});
app.get('/api/me',auth,(req,res)=>res.json(userById(req.user.uid)||null));
app.get('/api/statements',auth,(req,res)=>res.json(db.statements.filter(s=>s.uid===req.user.uid).sort((a,b)=>b.ts-a.ts)));
app.get('/api/notifications',auth,(req,res)=>res.json(db.notifications.slice(-50).reverse()));
app.post('/api/deposit',auth,(req,res)=>{
  const amount=Number(req.body.amount), method=String(req.body.method||''), trx=String(req.body.trxId||'').trim();
  if(!(amount>0)||!['bKash','Nagad'].includes(method)||!trx) return res.status(400).json({error:'Amount, method and transaction ID are required'});
  const d={id:id('dep'),uid:req.user.uid,amount,method,trxId:trx,status:'pending',ts:Date.now()};db.deposits.push(d);save(db);res.json(d);
});
app.post('/api/withdraw',auth,(req,res)=>{
  const amount=Number(req.body.amount), method=String(req.body.method||''), number=String(req.body.number||'').trim();
  const u=userById(req.user.uid);
  if(!(amount>=1)||!['bKash','Nagad'].includes(method)||!number) return res.status(400).json({error:'Valid amount, method and number are required'});
  if(u.balance<amount) return res.status(400).json({error:'Insufficient balance'});
  u.balance-=amount;
  const w={id:id('wd'),uid:u.id,amount,method,number,status:'pending',ts:Date.now()};db.withdrawals.push(w);
  db.statements.push({uid:u.id,type:'withdraw',amount:-amount,note:`${method} withdrawal request`,ts:Date.now()});save(db);res.json(w);
});
app.post('/api/matches/:matchId/join',auth,(req,res)=>{
  const m=db.matches.find(x=>x.id===req.params.matchId),u=userById(req.user.uid);
  if(!m||m.status!=='open')return res.status(404).json({error:'Match unavailable'});
  if(m.players.includes(u.id))return res.status(400).json({error:'Already joined'});
  if(u.balance<m.entryFee)return res.status(400).json({error:'Insufficient balance'});
  u.balance-=m.entryFee;u.matches=(u.matches||0)+1;m.players.push(u.id);m.filled=m.players.length;
  db.statements.push({uid:u.id,type:'entry',amount:-m.entryFee,note:`Joined ${m.title}`,ts:Date.now()});save(db);res.json({ok:true,roomId:m.roomId||null,roomPassword:m.roomPassword||null});
});

app.post('/api/admin/login',(req,res)=>{
  if(!ADMIN_TOKEN||req.body.token!==ADMIN_TOKEN)return res.status(401).json({error:'Invalid admin token'});
  res.json({ok:true});
});
app.get('/api/admin/overview',admin,(req,res)=>res.json({settings:db.settings,modes:db.modes,rules:db.rules,matches:db.matches,users:db.users,withdrawals:db.withdrawals,deposits:db.deposits}));
app.put('/api/admin/settings',admin,(req,res)=>{db.settings={...db.settings,...req.body};save(db);res.json(db.settings);});
app.put('/api/admin/rules',admin,(req,res)=>{db.rules={...db.rules,...req.body};save(db);res.json(db.rules);});
app.put('/api/admin/modes',admin,(req,res)=>{db.modes=Array.isArray(req.body)?req.body:db.modes;save(db);res.json(db.modes);});
app.post('/api/admin/matches',admin,(req,res)=>{
  const m={id:id('m'),title:String(req.body.title||'New Match'),modeId:String(req.body.modeId||'br'),entryFee:Number(req.body.entryFee||5),prize:Number(req.body.prize||0),maxPlayers:Number(req.body.maxPlayers||48),filled:0,players:[],startAt:String(req.body.startAt||''),roomId:String(req.body.roomId||''),roomPassword:String(req.body.roomPassword||''),status:'open'};
  db.matches.push(m);save(db);res.json(m);
});
app.patch('/api/admin/matches/:id',admin,(req,res)=>{const m=db.matches.find(x=>x.id===req.params.id);if(!m)return res.status(404).json({error:'Not found'});Object.assign(m,req.body);save(db);res.json(m);});
app.post('/api/admin/deposits/:id/approve',admin,(req,res)=>{const d=db.deposits.find(x=>x.id===req.params.id);if(!d)return res.status(404).json({error:'Not found'});if(d.status!=='pending')return res.status(400).json({error:'Already processed'});d.status='approved';const u=userById(d.uid);u.balance+=d.amount;db.statements.push({uid:u.id,type:'deposit',amount:d.amount,note:`${d.method} deposit approved`,ts:Date.now()});save(db);res.json(d);});
app.post('/api/admin/deposits/:id/reject',admin,(req,res)=>{const d=db.deposits.find(x=>x.id===req.params.id);if(!d)return res.status(404).json({error:'Not found'});d.status='rejected';save(db);res.json(d);});
app.post('/api/admin/withdrawals/:id/approve',admin,(req,res)=>{const w=db.withdrawals.find(x=>x.id===req.params.id);if(!w)return res.status(404).json({error:'Not found'});w.status='approved';save(db);res.json(w);});
app.post('/api/admin/withdrawals/:id/reject',admin,(req,res)=>{const w=db.withdrawals.find(x=>x.id===req.params.id);if(!w)return res.status(404).json({error:'Not found'});if(w.status==='pending'){const u=userById(w.uid);u.balance+=w.amount;db.statements.push({uid:u.id,type:'refund',amount:w.amount,note:'Withdrawal rejected/refunded',ts:Date.now()});}w.status='rejected';save(db);res.json(w);});

app.use(express.static(path.join(__dirname,'public')));
app.listen(PORT,()=>console.log(`ZyroX Arena API listening on ${PORT}`));
